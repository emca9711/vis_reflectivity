var NAVTREE =
[
  [ "PI Python Libraries", "index.html", [
    [ "License Agreement", "a00001.html", null ],
    [ "Version History", "a00002.html", null ],
    [ "Device connection", "a00003.html", null ],
    [ "Data recorder", "a00004.html", null ],
    [ "Package overview", "a00005.html", null ],
    [ "Packages", null, [
      [ "Packages", "namespaces.html", "namespaces" ],
      [ "Package Functions", "namespacemembers.html", [
        [ "All", "namespacemembers.html", "namespacemembers_dup" ],
        [ "Functions", "namespacemembers_func.html", null ],
        [ "Variables", "namespacemembers_vars.html", "namespacemembers_vars" ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"a00001.html",
"a00009.html#a48478819301964bd2fa801d1cc070b8d",
"a00009.html#a93fef4425ac549e40f11f05870148898",
"a00009.html#ae237171759796d954fd1e548834febc9",
"a00019.html#ae998370247eae7d5f138fbc9bbb10a5c",
"a00033.html#a28526475f82f4a9faeeab1ca0b93be43",
"a00033.html#a6efdc12b360d9d874609fef87e5cf2e2",
"a00033.html#ab50fa0f9df69e3405cb6a490eff21c17",
"a00033.html#afe35124d87708bb512c42a767d0b9b19"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';