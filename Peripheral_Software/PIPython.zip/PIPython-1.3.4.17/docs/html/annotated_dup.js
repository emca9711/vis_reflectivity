var annotated_dup =
[
    [ "pipython", "a00041.html", "a00041" ]
];