var a00052 =
[
    [ "FrozenClass", "a00008.html", null ],
    [ "GCSRaise", "a00014.html", null ]
];