var namespaces =
[
    [ "pipython", "a00041.html", "a00041" ]
];