var files =
[
    [ "__init__.py", "a00027.html", "a00027" ],
    [ "interfaces/__init__.py", "a00028.html", null ],
    [ "datarectools.py", "a00029.html", "a00029" ],
    [ "gcscommands.py", "a00030.html", "a00030" ],
    [ "gcsdevice.py", "a00031.html", [
      [ "GCSDevice", "a00010.html", "a00010" ]
    ] ],
    [ "gcsdll.py", "a00032.html", "a00032" ],
    [ "gcserror.py", "a00033.html", "a00033" ],
    [ "gcsmessages.py", "a00034.html", "a00034" ],
    [ "pigateway.py", "a00036.html", [
      [ "PIGateway", "a00015.html", "a00015" ]
    ] ],
    [ "piserial.py", "a00037.html", [
      [ "PISerial", "a00016.html", "a00016" ]
    ] ],
    [ "pisocket.py", "a00038.html", [
      [ "PISocket", "a00017.html", "a00017" ]
    ] ],
    [ "pitools.py", "a00039.html", "a00039" ],
    [ "replyserver.py", "a00040.html", "a00040" ]
];