var a00019 =
[
    [ "__send", "a00019.html#a82fdd950db325a5b3568a297560e6f46", null ],
    [ "__send_from_queue", "a00019.html#a203839d567a05a22f51a3d0ad254eca4", null ],
    [ "__send_from_static", "a00019.html#aa501ce90f4fa4344cb6266f222612560", null ],
    [ "__seterror", "a00019.html#ac1c048e0abd08c8d6cf8914fd27a8b87", null ],
    [ "__verify_answer", "a00019.html#ad18b2c76db99832ae6dcc4d8b7b0a47f", null ],
    [ "handle", "a00019.html#afa152fe78ac7b6398fa41e7e9585fa7e", null ],
    [ "delay", "a00019.html#ae998370247eae7d5f138fbc9bbb10a5c", null ],
    [ "errorbuf", "a00019.html#a761369ea1cbc046241a763d5bcac14be", null ],
    [ "queue", "a00019.html#abd24d721da2494a915dadd2a80047525", null ],
    [ "rotate", "a00019.html#ab3b55633e13a26b006d6bd1cbff36f34", null ],
    [ "static", "a00019.html#a4296e56f43753b2bdcb9a6f5758ad343", null ]
];