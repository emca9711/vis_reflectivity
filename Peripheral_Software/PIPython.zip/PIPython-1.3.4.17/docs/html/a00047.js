var a00047 =
[
    [ "gcsdll", "a00048.html", "a00048" ],
    [ "pigateway", "a00049.html", "a00049" ],
    [ "piserial", "a00050.html", "a00050" ],
    [ "pisocket", "a00051.html", "a00051" ]
];