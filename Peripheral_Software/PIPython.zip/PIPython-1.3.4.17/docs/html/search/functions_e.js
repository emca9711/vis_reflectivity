var searchData=
[
  ['nav',['NAV',['../a00009.html#ad76e2e6cfb7d415b38716f281cbf08fc',1,'pipython::gcscommands::GCSCommands']]],
  ['nlm',['NLM',['../a00009.html#a2ee0dd954f1d64f5301009d7f49da2e1',1,'pipython::gcscommands::GCSCommands']]],
  ['numaxes',['numaxes',['../a00009.html#a41eca3be868d6e74a6c5a9e73f7f1fcf',1,'pipython::gcscommands::GCSCommands']]],
  ['numvalues',['numvalues',['../a00007.html#adf329f5df9d069286e6f63b4680b02fc',1,'pipython.datarectools.Datarecorder.numvalues(self)'],['../a00007.html#a538314423b7e8690e78e65a60d7ec7f5',1,'pipython.datarectools.Datarecorder.numvalues(self, value)']]]
];
