var searchData=
[
  ['rec_5ferror_5f_5f3',['REC_ERROR__3',['../a00045.html#a4b12d0da9dfe5674c1ab3e7256e0c8c6',1,'pipython::gcserror']]],
  ['rotate',['rotate',['../a00019.html#ab3b55633e13a26b006d6bd1cbff36f34',1,'pipython.replyserver.ReplyHandler.rotate()'],['../a00020.html#a93fb89fa7cf900dc1ee9772e5d02fd72',1,'pipython.replyserver.ReplyServer.rotate()']]]
];
