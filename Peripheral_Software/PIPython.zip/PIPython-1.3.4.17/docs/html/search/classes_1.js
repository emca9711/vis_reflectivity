var searchData=
[
  ['frozenclass',['FrozenClass',['../a00008.html',1,'pipython::pitools']]]
];
