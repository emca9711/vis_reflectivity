var searchData=
[
  ['unicode',['unicode',['../a00043.html#ab1ebb82bc221eae9b7f3ddb49b1e3535',1,'pipython::gcscommands']]],
  ['unixdll',['UNIXDLL',['../a00048.html#a13969315ed4bade123264e00a1d90bd0',1,'pipython::interfaces::gcsdll']]]
];
