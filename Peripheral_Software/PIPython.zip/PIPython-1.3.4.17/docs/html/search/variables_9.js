var searchData=
[
  ['kd_5fof_5faxis_5f76',['KD_OF_AXIS_76',['../a00042.html#a35a9e52b5525c6e2918a3a37b1ce724f',1,'pipython::datarectools']]],
  ['ki_5fof_5faxis_5f75',['KI_OF_AXIS_75',['../a00042.html#a9f61975cbed4f715de3c7aba8f714b40',1,'pipython::datarectools']]],
  ['kp_5fof_5faxis_5f74',['KP_OF_AXIS_74',['../a00042.html#a75bd8ba0b551897131b8f1da7befdb95',1,'pipython::datarectools']]]
];
