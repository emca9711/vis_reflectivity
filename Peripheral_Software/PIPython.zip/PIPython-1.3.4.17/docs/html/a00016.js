var a00016 =
[
    [ "__init__", "a00016.html#afcd17cc156907f75c432b51d24ee3e3f", null ],
    [ "__enter__", "a00016.html#a361f4a7e6274ad1fb8e7b350ded63f9e", null ],
    [ "__exit__", "a00016.html#a5a51348776328097fda997fa23f55ed5", null ],
    [ "__str__", "a00016.html#a8d4c0e1b2efb19734d8f5e322c6c2f17", null ],
    [ "answersize", "a00016.html#aad8ae35d05632ade3ac195490360fe17", null ],
    [ "close", "a00016.html#acfbe4ae96132e744c81a4ab49594b45a", null ],
    [ "connectionid", "a00016.html#ad05e267be35ec6cdc09cd43f9db83c12", null ],
    [ "getanswer", "a00016.html#a25cfecdd399a9589e824239cbb39abd2", null ],
    [ "send", "a00016.html#a53a8e998ff022a848e7c11b834ed4c4e", null ],
    [ "__ser", "a00016.html#a713b30137c54b7931444fac9158ecc5a", null ]
];